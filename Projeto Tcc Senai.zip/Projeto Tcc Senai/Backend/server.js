const express = require("express")
const cors = require("cors")

const app = express()
const PORT = 3000

app.use(cors())
app.use(express.json())

let users = []

app.get("/", (req, res) => {
res.json({ message: "VIGILANTE API ONLINE" })
})

app.get("/users", (req, res) => {
res.json(users)
})

app.post("/register", (req, res) => {
const { nome, email, senha } = req.body

if (!nome || !email || !senha) {
return res.status(400).json({ message: "Dados incompletos" })
}

const exists = users.find(u => u.email === email)

if (exists) {
return res.status(400).json({ message: "Usuário já existe" })
}

const newUser = {
id: Date.now(),
nome,
email,
senha
}

users.push(newUser)

res.json({ message: "Usuário criado", user: newUser })
})

app.post("/login", (req, res) => {
const { email, senha } = req.body

const user = users.find(u => u.email === email && u.senha === senha)

if (!user) {
return res.status(401).json({ message: "Login inválido" })
}

res.json({
message: "Login realizado",
user: {
id: user.id,
nome: user.nome,
email: user.email
}
})
})

app.listen(PORT, () => {
console.log(`Servidor rodando na porta ${PORT}`)
})